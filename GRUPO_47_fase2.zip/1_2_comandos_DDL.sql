/*a)    O nome do cliente dentro da tabela T_MC_CLIENTE está como único. Favor excluir essa restrição. Qual é a instrução SQL ideal para executar essa ação?

RESPOSTA:*/

	ALTER TABLE T_MC_CLIENTE
		DROP CONSTRAINT UK_MC_CLIENTE_NOME_CLIENTE;

/*b)    As colunas QT_ESTRELAS, ST_CLIENTE e DS_EMAIL da tabela T_MC_CLIENTE devem ser obrigatórias. Favor realizar esse ajuste. Quais as instruções SQL ideais para executar essa ação?

RESPOSTA:*/

	ALTER TABLE T_MC_CLIENTE
		MODIFY QT_ESTRELAS NUMBER(1) NOT NULL
		MODIFY ST_CLIENTE CHAR(1) NOT NULL
		MODIFY DS_EMAIL VARCHAR2(100) NOT NULL;
		
/*c)     A coluna NM_LOGIN da tabela T_MC_CLIENTE deve receber conteúdo único. Favor realizar esse ajuste. Qual é a instrução SQL ideal para executar essa ação?
	
RESPOSTA:*/

	ALTER TABLE T_MC_CLIENTE
		ADD CONSTRAINT UK_MC_CLIENTE_NM_LOGIN UNIQUE (NM_LOGIN);

/*d)    As colunas DT_FUNDACAO e NR_CNPJ da tabela T_MC_CLI_JURIDICA devem ter conteúdo como sendo obrigatório. Quais as instruções SQL ideais para executar essa ação?

RESPOSTA:*/

	ALTER TABLE T_MC_CLI_JURIDICA
		MODIFY NR_CNPJ VARCHAR2(20) NOT NULL
		MODIFY DT_FUNDACAO DATE NOT NULL;
    
/*e)    As colunas NR_MINUTO_VIDEO e NR_SEGUNDO_VIDEO na parte de controle da visualização do vídeo devem ter conteúdos obrigatórios. Identifique o nome da tabela e realize esses ajustes.

RESPOSTA:*/

	ALTER TABLE T_MC_SGV_VISUALIZACAO_VIDEO
		MODIFY NR_MINUTO_VIDEO NUMBER(2,0) NOT NULL
		MODIFY NR_SEGUNDO_VIDEO NUMBER(2,0) NOT NULL;
    
/*f)      As colunas ST_PRODUTO, ST_VIDEO_PROD, ST_END, ST_FUNC e ST_CATEGORIA somente pode receber dois valores possíveis: A ou I, sendo (A)tivo ou (I)nativo. Identifique em quais tabelas se localizam essas colunas e realize os ajustes.

RESPOSTA:*/

	ALTER TABLE T_MC_PRODUTO
		ADD CONSTRAINT CK_MC_CLIENTE_ST_PRODUTO CHECK (ST_PRODUTO = UPPER('A') OR ST_PRODUTO=UPPER('I'));
		
	ALTER TABLE T_MC_SGV_PRODUTO_VIDEO
		ADD CONSTRAINT CK_SGV_PROD_VID_ST_VIDEO_PROD CHECK (ST_VIDEO_PROD = UPPER('A') OR ST_VIDEO_PROD=UPPER('I'));	
	
	ALTER TABLE T_MC_END_CLI
		ADD CONSTRAINT CK_T_MC_END_CLI_ST_END CHECK (ST_END = UPPER('A') OR ST_END=UPPER('I'));
    
	ALTER TABLE T_MC_END_FUNC
		ADD CONSTRAINT CK_T_MC_END_FUNC_ST_END CHECK (ST_END = UPPER('A') OR ST_END=UPPER('I'));
		
	ALTER TABLE T_MC_FUNCIONARIO
		ADD CONSTRAINT CK_T_MC_FUNCIONARIO_ST_FUNC CHECK (ST_FUNC = UPPER('A') OR ST_FUNC=UPPER('I'));
	
	ALTER TABLE T_MC_CATEGORIA_PROD
		ADD CONSTRAINT CK_MC_CATEGORIA_ST_CATEGORIA CHECK (ST_CATEGORIA = UPPER('A') OR ST_CATEGORIA=UPPER('I'));